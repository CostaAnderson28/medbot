import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { getDb } from '../db/setup.js';
import { generateToken } from '../middleware/auth.js';
const router = Router();
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email e senha obrigatorios' });
  const db = getDb();
  const doc = db.prepare('SELECT * FROM doctors WHERE email = ?').get(email);
  db.close();
  if (!doc || !bcrypt.compareSync(password, doc.password)) return res.status(401).json({ error: 'Email ou senha incorretos' });
  res.json({ token: generateToken(doc), doctor: { id: doc.id, name: doc.name, clinic: doc.clinic, email: doc.email, bot_active: doc.bot_active } });
});
export default router;
