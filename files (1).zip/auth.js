import jwt from 'jsonwebtoken';
const SECRET = process.env.JWT_SECRET || 'oftalmo-chatbot-secret-2024';
export function generateToken(doc) { return jwt.sign({ id: doc.id, email: doc.email }, SECRET, { expiresIn: '7d' }); }
export function authMiddleware(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ error: 'Token nao fornecido' });
  try { const d = jwt.verify(h.split(' ')[1], SECRET); req.doctorId = d.id; next(); }
  catch (e) { return res.status(401).json({ error: 'Token invalido' }); }
}
